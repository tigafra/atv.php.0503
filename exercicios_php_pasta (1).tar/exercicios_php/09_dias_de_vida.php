<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dias de Vida</title>
</head>
<body>
<form method="post">
Nome:
<input type="text" name="nome" required>
Idade:
<input type="number" name="idade" required>
<button>Calcular</button>
</form>
<?php
if(isset($_POST["nome"])){
    $nome = $_POST["nome"];
    $idade = $_POST["idade"];
    $diasVividos = $idade * 365;
    echo "<h3>$nome já viveu aproximadamente $diasVividos dias</h3>";
}
?>
</body>
</html>