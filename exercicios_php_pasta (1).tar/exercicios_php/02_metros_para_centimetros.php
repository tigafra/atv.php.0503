<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Conversão</title>
</head>
<body>
<?php
$medidaMetros = 5.5;
$medidaCentimetros = $medidaMetros * 100;
echo "<h2>$medidaMetros metros correspondem a $medidaCentimetros centímetros</h2>";
?>
</body>
</html>