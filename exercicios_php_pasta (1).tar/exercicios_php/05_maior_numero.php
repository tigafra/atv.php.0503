<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Maior Número</title>
</head>
<body>
<form method="post">
<input type="number" name="a" required>
<input type="number" name="b" required>
<input type="number" name="c" required>
<button>Verificar</button>
</form>
<?php
if(isset($_POST["a"])){
    $a = $_POST["a"];
    $b = $_POST["b"];
    $c = $_POST["c"];
    $maior = max($a,$b,$c);
    echo "<h3>Maior valor: $maior</h3>";
}
?>
</body>
</html>