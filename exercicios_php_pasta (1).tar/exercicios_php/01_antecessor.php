<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Antecessor</title>
</head>
<body>
<form method="post">
Digite um número:
<input type="number" name="valor" required>
<button>Mostrar</button>
</form>
<?php
if(isset($_POST["valor"])){
    $valorDigitado = $_POST["valor"];
    $resultado = $valorDigitado - 1;
    echo "<h2>O número anterior é: $resultado</h2>";
}
?>
</body>
</html>