<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Tabuada</title>
</head>
<body>
<form method="post">
Número:
<input type="number" name="numero">
<button>Calcular</button>
</form>
<?php
if(isset($_POST["numero"])){
    $num = $_POST["numero"];
    echo "<h3>Tabuada do $num</h3>";
    for($contador = 1; $contador <= 10; $contador++){
        $resultado = $num * $contador;
        echo "$num x $contador = $resultado <br>";
    }
}
?>
</body>
</html>