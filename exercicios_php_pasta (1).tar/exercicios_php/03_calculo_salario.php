<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Salário Mensal</title>
</head>
<body>
<form method="post">
Valor recebido por hora:
<input type="number" step="0.01" name="valorHora" required><br><br>
Horas trabalhadas no mês:
<input type="number" name="horasMes" required><br><br>
<button>Calcular</button>
</form>
<?php
if(isset($_POST["valorHora"]) && isset($_POST["horasMes"])){
    $hora = $_POST["valorHora"];
    $horasTrabalhadas = $_POST["horasMes"];
    $total = $hora * $horasTrabalhadas;
    echo "<h3>Salário do mês: R$ ".number_format($total,2,",",".")."</h3>";
}
?>
</body>
</html>