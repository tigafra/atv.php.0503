<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Números Ímpares</title>
</head>
<body>
<h3>Números ímpares entre 1 e 50</h3>
<?php
for($n = 1; $n <= 50; $n++){
    if($n % 2 != 0){
        echo $n." ";
    }
}
?>
</body>
</html>