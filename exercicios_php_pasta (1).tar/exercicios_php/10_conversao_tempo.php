<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Conversão de Tempo</title>
</head>
<body>
<form method="post">
Tempo em segundos:
<input type="number" name="segundos" required>
<button>Converter</button>
</form>
<?php
if(isset($_POST["segundos"])){
    $tempo = $_POST["segundos"];
    $horas = floor($tempo / 3600);
    $minutos = floor(($tempo % 3600) / 60);
    $seg = $tempo % 60;
    echo "<h3>$horas h $minutos min $seg s</h3>";
}
?>
</body>
</html>