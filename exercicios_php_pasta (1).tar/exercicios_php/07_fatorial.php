<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Fatorial</title>
</head>
<body>
<form method="post">
<input type="number" name="numero" required>
<button>Calcular</button>
</form>
<?php
if(isset($_POST["numero"])){
    $numero = $_POST["numero"];
    $resultado = 1;
    for($i=1; $i <= $numero; $i++){
        $resultado *= $i;
    }
    echo "<h3>$numero! = $resultado</h3>";
}
?>
</body>
</html>