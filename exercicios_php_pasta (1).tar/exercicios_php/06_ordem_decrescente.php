<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Ordem Decrescente</title>
</head>
<body>
<form method="post">
<input type="number" name="valores[]" required>
<input type="number" name="valores[]" required>
<input type="number" name="valores[]" required>
<button>Ordenar</button>
</form>
<?php
if(isset($_POST["valores"])){
    $lista = $_POST["valores"];
    rsort($lista);
    echo "<h3>Números em ordem decrescente:</h3>";
    foreach($lista as $item){
        echo $item." ";
    }
}
?>
</body>
</html>